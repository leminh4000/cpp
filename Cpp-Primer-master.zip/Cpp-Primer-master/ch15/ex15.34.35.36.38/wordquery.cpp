#include "wordquery.h"

